using Net.Essentials;
using Net.UI;

namespace $rootnamespace$
{
	public partial class $safeitemname$
	{
		public $safeitemname$()
		{
			InitializeComponent();
		}
	}
}