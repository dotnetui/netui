﻿using Net.Essentials;

namespace $rootnamespace$
{
    public class $safeitemname$ : ViewModel
    {

    }
}