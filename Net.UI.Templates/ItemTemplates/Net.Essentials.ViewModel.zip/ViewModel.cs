﻿namespace $rootnamespace$;

public class $safeitemname$ : Net.Essentials.ViewModel
{

}